//Håndterer kamera eller viewport bevegelse slik at kamera beveger seg med spiller

let camPanX = 0.0;
let camPanY = 0.0;


const PLAYER_DIST_FROM_CENTER_BEFORE_CAMERA_PAN_X = 100; //konstanter for den "frie" bevegelseboksen
const PLAYER_DIST_FROM_CENTER_BEFORE_CAMERA_PAN_Y = 50;

function instantCamFollow() { 
  camPanX = player.x + canvas.width/2;
  camPanY = player.y + canvas.height/2;
}

function cameraFollow() {
  let cameraFocusCenterX = camPanX + canvas.width/2;
  let cameraFocusCenterY = camPanY + canvas.height/2;

  let playerDistFromCameraFocusX = Math.abs(player.x - cameraFocusCenterX);
  let playerDistFromCameraFocusY = Math.abs(player.y - cameraFocusCenterY);

  if (playerDistFromCameraFocusX > PLAYER_DIST_FROM_CENTER_BEFORE_CAMERA_PAN_X) {
    if (cameraFocusCenterX < player.x) {
      camPanX += player.speed;
    } else {
      camPanX -= player.speed;
    }
  }
  if (playerDistFromCameraFocusY > PLAYER_DIST_FROM_CENTER_BEFORE_CAMERA_PAN_Y) {
    if (cameraFocusCenterY < player.y) {
      camPanY += player.speed;
    } else {
      camPanY -= player.speed;
    }
  }

// ikke vise "out of bounds"

  /*if (camPanX < 0) {
    camPanX = 0;
  }
  if (camPanY < 0) {
    camPanY = 0;
  }
  let maxPanRight = WORLD_COL * TILE_W - canvas.width;
  let maxPanTop = WORLD_ROW * TILE_H - canvas.width;
  if (camPanX > maxPanRight) {
    camPanX = maxPanRight;
  }
  if (camPanY > maxPanTop) {
    camPanY = maxPanTop;
  }*/
}
