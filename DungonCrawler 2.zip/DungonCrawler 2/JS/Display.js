//Håndterer ulike utsende status siden

//henter alle ellementer som trengs

const loggInnConteinerEl = document.getElementById('loggInnConteiner');
const logInFieldEl = document.getElementById('logInField');
const titleEl = document.getElementById('title');
const infoBoxEl = document.getElementById('infoBox');
const infoEl = document.getElementById('info');
const beforeGameEl = document.getElementById('beforeGame');


function showDisplay(whatDisplay) {
  if (whatDisplay == "start") {
    titleEl.innerHTML = "Emriks dungon crawler";
    infoEl.innerHTML = "Logg inn for å spille spillet";

    loggInnConteinerEl.style.visibility = 'visible';

    btnLogIn.style.visibility = "visible";
    btnSignUp.style.visibility = "visible";
    logInFieldEl.style.visibility = "visible";

    btnLogOut.style.visibility = "hidden";
    btnCreateUser.style.visibility = "hidden";
    btnBack.style.visibility = "hidden";
    signupForm.style.visibility = "hidden";
  }

  if (whatDisplay == "createUser") {
    btnCreateUser.style.visibility = "visible";
    btnBack.style.visibility = "visible";
    signupForm.style.visibility = "visible";

    btnSignUp.style.visibility = "hidden";
    btnLogIn.style.visibility = "hidden";
    btnLogOut.style.visibility = "hidden";
    logInFieldEl.style.visibility = "hidden";
  }

  if (whatDisplay == "playGame") {
    btnLogOut.style.visibility = "visible";

    btnSignUp.style.visibility = "hidden";
    loggInnConteinerEl.style.visibility = "hidden";
    signupForm.style.visibility = "hidden";
    btnBack.style.visibility = "hidden";
    btnCreateUser.style.visibility = "hidden";
  }
}
