//Setter opp lytter innput

//Constanter for ulike knapper
const KEY_LEFT_ARROW = 37;
const KEY_UP_ARROW = 38;
const KEY_RIGHT_ARROW = 39;
const KEY_DOWN_ARROW = 40;
const KEY_EVENT = 13;

function setupInput() { //setter opp input når siden laster
  document.addEventListener("keydown", keyPressed);
  document.addEventListener("keyup", keyReleasted);

  player.setupInput(KEY_UP_ARROW, KEY_RIGHT_ARROW, KEY_DOWN_ARROW, KEY_LEFT_ARROW, KEY_EVENT);
}

function keySet(keyEvent, whichPlayer, setTo) {
  if (keyEvent.keyCode == whichPlayer.controlKeyLeft) {
    whichPlayer.keyHeld_West = setTo;
  }
  if(keyEvent.keyCode == whichPlayer.controlKeyRight) {
    whichPlayer.keyHeld_East = setTo;
  }
  if(keyEvent.keyCode == whichPlayer.controlKeyUp) {
    whichPlayer.keyHeld_North = setTo;
  }
  if(keyEvent.keyCode == whichPlayer.controlKeyDown) {
    whichPlayer.keyHeld_South = setTo;
  }
  if (keyEvent.keyCode == whichPlayer.controlKeyEvent) {
    whichPlayer.keyHeld_Event = setTo;
  }
}


function keyPressed(evt) { //Sjekker når knappen trykkes på
  keySet(evt, player, true);
  evt.preventDefault(); //Hindrer at browser beveger seg når man trykker på knappene

}

function keyReleasted(evt) { //Sjekker når knappen slippes
  keySet(evt, player, false);
  player.moving = false;
}
