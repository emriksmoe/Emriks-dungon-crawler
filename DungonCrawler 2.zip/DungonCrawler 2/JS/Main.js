//setter sammen ulike funksjoner

let canvas, ctx, imageLoadingDone; //setter opp canvas

window.onload = function () { //laster og setter opp ting når siden laseter
  canvas = document.getElementById('canvas');
  ctx = canvas.getContext('2d');
  imageLoadingDone = false;

  colorRect(0,0, canvas.width,canvas.height, 'black');

  loadImages(); //laster inn bilder før man forsetter
}

function gameReadyToStart() { //starter når bilder har lastet og om spiller er logget inn
  if (imageLoadingDone) {
    setUpPlayer();
    let framesPerSecond = 30;
    setInterval(updateAll, 1000/framesPerSecond);

    setupInput();

    loadLevel(levelList[correctDataSet.currentLevel]);
  }
}


function loadLevel(wichLevel) { //laseter inn level basserrt på hvilken level
  worldGrid = wichLevel.slice();
  setUpNPCs();
  for (let i = 0; i < guards.length; i++) {
    guards[i].spawn();
    console.log("spawn");
  }
  for (let i = 0; i < salesmen.length; i++) {
    salesmen[i].spawn();
  }
  for (let i = 0; i < enemies.length; i++) {
    enemies[i].spawn();
  }
  player.reset();
}


function drawAll() { //tegner alt som skal tegnes på siden
  colorRect(0, 0, canvas.width, canvas.height, 'black');
  ctx.save();
  ctx.translate(-camPanX, -camPanY);
  drawWorld();
  for (let i = 0; i < guards.length; i++) { //går gjennom NPCene og tegner de
    guards[i].draw();
  }
  for (let i = 0; i < salesmen.length; i++) {
    salesmen[i].draw();
  }
  for (let i = 0; i < enemies.length; i++) {
    enemies[i].draw();
  }
  player.handlePlayerFrame();
  player.draw();
  if (someoneIsTalking) { //Sjekker om noen snakker
    talkingNPC(textInBuble, typeNPC,wichOne, boxWidth, boxHeight);
  }
  ctx.restore();
}


function moveAll() { //Håndter all bevegelse
  player.move();
  cameraFollow();
}

function updateAll() { //oppdaterr alt
  worldEvent();
  drawAll();
  moveAll();
  player.playerEvents();
}
