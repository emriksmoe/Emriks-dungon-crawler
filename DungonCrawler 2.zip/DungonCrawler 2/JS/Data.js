//håndterer alt av data

//erklærer variabler
const database = firebase.database();
let ref = database.ref("/Players/");
let correctDataSet;
let path;
let correctPath;
let userRef;


function uploadNewPlayer(skin) { //laster opp en helt ny spiller når ny spiler lages
  ref.push({
    name: firebase.auth().currentUser.displayName,
    uid: firebase.auth().currentUser.uid,
    email: firebase.auth().currentUser.email,
    skin: skin,
    currentLevel: 0,
    haveNotWon: false,
    totalGold: 0,
    totalBattery: 0,
    totalTuborg: 0,
    worldOne: worldOne,
    worldTwo: worldTwo,
    worldTree: worldTree,
    worldFour: worldFour,
  });
}

function gotData(data) { //finner riktig data sett
  let players = data.val();
  let keys = Object.keys(players);
  for (let i = 0; i < keys.length; i++) {
    if (players[keys[i]].uid== firebase.auth().currentUser.uid) {
      correctPath = keys[i];
      userRef = database.ref("/Players/" + correctPath); //gjør at spillet vet hvilken data base som kan endres
      correctDataSet = players[keys[i]]; //gjør at man kan hennvise til riktig datasett
      console.log(correctPath);
    }
  }
  currentLevel = correctDataSet.currentLevel;
  levelList = [correctDataSet.worldOne, correctDataSet.worldTwo,  correctDataSet.worldTree, correctDataSet.worldFour];
  gatherdBattery = correctDataSet.totalBattery;
  gatherdGold = correctDataSet.totalGold;
  gatherdTuborg = correctDataSet.totalTuborg;
  haveNotWon = correctDataSet.haveNotWon;
  gameReadyToStart();
}

function errData(err) {
  console.log('Error');
  console.log(err);
}

function saveData() { //lagrer ny data til spesifikk spiller
  userRef.update({
    currentLevel: currentLevel,
    totalBattery: gatherdBattery,
    totalGold: gatherdGold,
    totalTuborg: gatherdTuborg,
    haveNotWon: haveNotWon,
  });
}

function saveWorld() {
  if (currentLevel == 0) {
    userRef.update({
      worldOne: worldGrid.slice(),
    });
  }
  if (currentLevel == 1) {
    userRef.update({
      worldTwo: worldGrid.slice(),
    });
  }
  if (currentLevel == 2) {
    userRef.update({
      worldTree: worldGrid.slice(),
    });
  }
  if (currentLevel == 3) {
    userRef.update({
      worldFour: worldGrid.slice(),
    });
  }
}

 function handleDataForNextLevel() {
 saveWorld();
 currentLevel++;
 saveData();
 location.reload();
}

  function handleDateForPreviusLevel() {
    saveWorld();
    currentLevel--;
    saveData();
    location.reload();
}
