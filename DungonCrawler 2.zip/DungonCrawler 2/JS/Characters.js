'use strict' //setter opp spilleren

const PLAYER_MOVE_SPEED = 5.0; //ulike konstanter og variabler for spiller
let numberOfPlayer = 0;
let gatherdGold = 0;
let eventDone = 0;
let gatherdBattery = 0;
let gatherdTuborg = 0;
let coolDown = true;
let wait = true;

class Character{
  constructor(sprite, width,height, speed){ //setter opp nødvendig informasjon for spillerern
    this.sprite = sprite;
    this.x = 0;
    this.y = 0;
    this.width = width;
    this.height = height;
    this.speed = speed;

    this.spawnBlock = floorKind[currentLevel];

    this.frameX = 0;
    this.frameY = 0;
    this.moving = false;
    this.action = false;

    this.keyHeld_North = false;
    this.keyHeld_South = false;
    this.keyHeld_East = false;
    this.keyHeld_West = false;
    this.keyHeld_Event = false;

    this.controlKeyUp;
    this.controlKeyDown;
    this.controlKeyLeft;
    this.controlKeyRight;
    this.controlKeyEvent;

    this.playerSprite = new Image();
    this.playerSprite.src = this.sprite;

    this.health = 100;
  }

  setupInput(upKey, rightKey, downKey, leftKey, eventKey) { //Setter opp input for spiller
    this.controlKeyUp = upKey;
    this.controlKeyRight = rightKey;
    this.controlKeyDown = downKey;
    this.controlKeyLeft = leftKey;
    this.controlKeyEvent = eventKey;
  }

  draw() { //tegner spriten til spiller
    drawSprite(this.playerSprite, this.width * this.frameX,this.height * this.frameY, this.width,this.height, this.x,this.y, this.width,this.height);
  }

  reset() { //Plasserer spioller ved riktig posisjon når siden laster inn eller nytt "map" laster
    for(let eachRow=0; eachRow<WORLD_ROW; eachRow++) {
      for(let eachCol=0; eachCol<WORLD_COL; eachCol++) {
        let arrayIndex = rowColToArrayIndex(eachCol, eachRow);
        if (worldGrid[arrayIndex] == PLAYER_START_BRICKS || worldGrid[arrayIndex] == PLAYER_START_PLANKS) {
          this.x = eachCol * TILE_W;
          this.y = eachRow * TILE_H - TILE_H/2;
          return;
        } //slutt på player start
      }
    }
    console.log("NO PLAYER FOUND");
  }

  playerEvents() { //håndterer spiller events

      if (this.keyHeld_Event && coolDown) { //presser action button BARE FOR LEVEL 1
        if (countMoving < 1) {
          movingEnemy = true;
          countMoving++;
        } else {
          movingEnemy = false;
          countMoving = 0;
        }
        coolDown = false;

        if (currentLevel == 0) { //for første level
          for (let i = 0; i < guards.length; i++) {
            if (getDistance(player, guards[i]) < 100) {
              typeNPC = guards;
              wichOne = i;
              if (gatherdGold >= 5) {
                for (let i = 0; i < worldGrid.length; i++) {
                  if (worldGrid[i] == MOVING_WALL) {
                    worldGrid[i] = floorKind[currentLevel];;
                    textInBuble = "Velkommen inn";
                    someoneIsTalking = true;
                    boxWidth = 180;
                    boxHeight = 25;
                  }
                }
              } else {
               textInBuble = "Du må ha mer gull";
               someoneIsTalking = true;
               boxWidth = 210;
               boxHeight = 25;
              }
            }
          }
        }

        if (currentLevel == 2) {
          console.log("skjer");
          for (let i = 0; i < guards.length; i++) {
            typeNPC = guards;
            wichOne = i;
            console.log("skjer mer");
            if (getDistance(player, guards[i]) < 100) {
              console.log("skjer enda mer");
              textInBuble = "Du er nesten ferdig! Bare finn riktig teleporteringsblokk og du har vunnet!";
              someoneIsTalking = true;
              boxWidth = 400;
              boxHeight = 50;
            }
          }
        }

//generelle hendelser
      for (let i = 0; i < salesmen.length; i++) {
        if (getDistance(player, salesmen[i]) < 100) {
          console.log("handle?");
        }
      }

        setTimeout(function() { //hindrer spam
          coolDown = true;
          someoneIsTalking = false;

          textInBuble = 0;
          typeNPC = 0;
          wichOne = 0;
          boxWidth = 0;
          boxHeight = 0;
        }, 1000);
      }
    }

playerDirection() {
  if (this.keyHeld_North) {
    this.y += this.speed;
  }
  if (this.keyHeld_South) {
    this.y -= this.speed;
  }
  if (this.keyHeld_East) {
    this.x -= this.speed;
  }
  if (this.keyHeld_West) {
    this.x += this.speed;
  }
}

playerNPChit(whichNPC) {

}


  move() { //håndterer bevegelsen til spilleren
    let nextX = this.x;
    let nextY = this.y;

    if(this.keyHeld_North) { //hvis knappen er trykket beveg soilleen
      nextY -= this.speed;
      this.moving = true;
      this.frameY = 3;
    }
    if(this.keyHeld_East) {
      nextX += this.speed;
      this.moving = true;
      this.frameY = 2;
    }
    if(this.keyHeld_South) {
      nextY += this.speed;
      this.moving = true;
      this.frameY = 0;
    }
    if(this.keyHeld_West) {
      nextX -= this.speed;
      this.moving = true;
      this.frameY = 1;
    }

   let walkIntoTileIndex = getTileIndexAtPixelCoord(nextX, nextY);
   let walkIntoTileType = FLOOR_BRICKS;

   if (walkIntoTileIndex != undefined) {
     walkIntoTileType = worldGrid[walkIntoTileIndex];
   }

   switch(walkIntoTileType) { //håndterer hva som skjer når man går inn i ny tile
     case PLAYER_START_BRICKS:
       this.x = nextX;
       this.y = nextY;
       break;

     case PLAYER_START_PLANKS:
       this.x = nextX;
       this.y = nextY
       break;

     case FLOOR_BRICKS:
      this.x = nextX;
      this.y = nextY;
      break;

     case PLANKS:
      this.x = nextX;
      this.y = nextY;
      break;

     case GOLD: //Endrer gull til floor_bricks
      worldGrid[walkIntoTileIndex] = floorKind[currentLevel];
      gatherdGold++;
      break;

     case METAL_TURK:
       this.x = nextX;
       this.y = nextY;
       if (wait) {
         handleDataForNextLevel();
       }
       wait = false;
      break;

    case METAL_GRAY:
     this.x = nextX;
     this.y = nextY;
     if (wait) {
       handleDateForPreviusLevel();
     }
     wait = false;
    break;

    case BATTERY_FRESH:
     worldGrid[walkIntoTileIndex] = floorKind[currentLevel];
     gatherdBattery++;
     break;

    case TUBORG:
     worldGrid[walkIntoTileIndex] = floorKind[currentLevel];
     gatherdTuborg++;
     break;

    default:
      break;
   }
  }

  handlePlayerFrame() { //håndterer hvilken "frame" av spilleren som vises basert på retningen spilleren går
    if (this.frameX < 3 && this.moving) {
      this.frameX++;
    } else {
      this.frameX = 0;
    }
  }
}



let player = new Character("", 0,0, 0);

function setUpPlayer() { //setter opp spilleren
  if (correctDataSet.skin == 0) {
    player = new Character("assets/chewie.png", 40,72, 4); //oppretter karakter
  }
  if (correctDataSet.skin == 1) {
    player = new Character("assets/indianajones.png", 32,48, 5);
  }
  if (correctDataSet.skin == 2) {
    player = new Character("assets/thor.png", 32,48, 6);
  }
}
