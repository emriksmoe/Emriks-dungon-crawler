//Håndterer globale hendelser

let firstGreeting = 0;
let someoneIsTalking = false;
let textInBuble = 0;
let typeNPC = 0;
let wichOne = 0;
let boxWidth = 0;
let boxHeight = 0;
let check = false;
let haveNotWon = true;

function getDistance(obj1, obj2) { //finner distansen mellom 2 obijekter
  let xDistance2 = Math.pow(obj1.x - obj2.x, 2);
  let yDistance2 = Math.pow(obj1.y - obj2.y, 2);
  let distance = Math.sqrt(xDistance2 + yDistance2);
  return distance;
}

function getRandom(maxSize) { //finner et random tall basert på en max grense
  return parseInt(Math.random()*maxSize);
}


function intersects(a, b) { //sjekker om rektangelen rundt den tegnede figuren rører hverandre
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y  && a.y + a.height > b.y;
}


function checkCollisions() { //sjekker om spilleren koliderer med NPCs
  for (var i = 0; i < guards.length; i++) {
    if (intersects(player, guards[i])) {
      player.playerDirection();
    }
  }
  for (var i = 0; i < enemies.length; i++) {
    if (intersects(player, enemies[i])) {
      player.playerDirection();
    }
  }
  for (var i = 0; i < salesmen.length; i++) {
    if (intersects(player, salesmen[i])) {
      player.playerDirection();
    }
  }
}


function worldEvent() { //Håndterer verdenshendelse
  if (currentLevel == 3 && haveNotWon) {
    alert("Gratulere du vant!" + "<br>" +
    "du samlett inn " + correctDataSet.totalGold + " guld, " + correctDataSet.totalBattery + " battery fresh og "
    + correctDataSet.totalTuborg + " tuborg");
    haveNotWon = false;
    saveData();
  }

 for (var i = 0; i < guards.length; i++) { //Går gjennom alle vaktene
   if (getDistance(player, guards[i]) < 100 && firstGreeting == 0) { //sjekker distansen mellom spiller og alle vaktene og om de har møttes
     firstGreeting++;
     textInBuble = "hei";
     typeNPC = guards;
     wichOne = i;
     someoneIsTalking = true;

     boxWidth = 40;
     boxHeight = 25;

     setTimeout(function() { //hindrer spam
       someoneIsTalking = false;
       textInBuble = 0;
       typeNPC = 0;
       wichOne = 0;
       boxWidth = 0;
       boxHeight = 0;
     }, 2000);
   }
 }
 checkCollisions();
}
