//laster inn bilder slik at siden ikke starter før siden laster

let tilePics = new Array();
let picsToLoad = 0;
let tileList = [];

function countLoadedImagesAndLaunchIfReady() { //sjekker om alle bildene er lastet
  picsToLoad--;
  // console.log(picsToLoad);
  if (picsToLoad == 0) {
    imageLoadingDone = true;
    //gameReadyToStart();
  }
}



function beginLoadingImages(imgVar, fileName) {
  imgVar.onload = countLoadedImagesAndLaunchIfReady;
  imgVar.src = "assets/" + fileName;
}

function loadImageForWorldCode(worldCode, fileName) {
  tilePics[worldCode] = document.createElement("img");
  beginLoadingImages(tilePics[worldCode], fileName);
}



function loadImages() {
  let tileList = [
    {
      tileType: PLANKS,
      theFile: "planks.png"
    },
    {
      tileType: METAL_GRAY,
      theFile: "metal_gray.png"
    },
    {
      tileType: METAL_TURK,
      theFile: "metal_turk.png"
    },
    {
      tileType: BRICKS,
      theFile: "bricks.png"
    },
    {
      tileType: BRICK_BARS,
      theFile: "bricks_bars.png"
    },
    {
      tileType: GOLD,
      theFile: "gold.png"
    },
    {
      tileType: RED_PLANKS,
      theFile: "red_houseplanks.png"
    },
    {
      tileType: FLOOR_BRICKS,
      theFile: "floor_bricks.png"
    },
    {
      tileType: BATTERY_FRESH,
      theFile: "battery_fresh.png"
    },
    {
      tileType: TUBORG,
      theFile: "tuborg.png"
    },
    {
      tileType: MOVING_WALL,
      theFile: "red_houseplanks.png"
    },
    {
      tileType: WEPON_TILE_ONE,
      theFile: "spear.png"
    },
    {
      tileType: WEPON_TILE_TWO,
      theFile: "simple_sword.png"
    },
    {
      tileType: WEPON_TILE_TREE,
      theFile: "attack_on_titan_sword.png"
    },
    {
      tileType: WEPON_TILE_FOUR,
      theFile: "simple_modern_gun.png"
    },
    {
      tileType: WEPON_TILE_FIVE,
      theFile: "simple_future_gun.png"
    },
    {
      tileType: LOG,
      theFile: "log.png"
    },
    {
      tileType: PLAYER_START_BRICKS,
      theFile: "floor_bricks.png"
    },
    {
      tileType: PLAYER_START_PLANKS,
      theFile: "planks.png"
    },
    {
      tileType: GUARD_SPAWN_BRICKS,
      theFile: "floor_bricks.png"
    },
    {
      tileType: GUARD_SPAWN_PLANKS,
      theFile: "planks.png"
    },
    {
      tileType: ENEMY_SPAWN_BRICKS,
      theFile: "floor_bricks.png"
    },
    {
      tileType: ENEMY_SPAWN_PLANKS,
      theFile: "planks.png"
    },
    {
      tileType: SALESMAN_SPAWN_BRICKS,
      theFile: "floor_bricks.png"
    },
    {
      tileType: SALESMAN_SPAWN_PLANKS,
      theFile: "planks.png"
    },
  ];

  picsToLoad = tileList.length;

  for (var i = 0; i < tileList.length; i++) {
    loadImageForWorldCode(tileList[i].tileType, tileList[i].theFile);
  }
}
