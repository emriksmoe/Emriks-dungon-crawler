'use strict' //setter opp NPCene

let guards = new Array; //Lager arrays man kan putte inn NPC i
let salesmen = new Array;
let enemies = new Array;

let movingEnemy = false;
let countMoving = 0;

function talkingNPC(text, type, which, width,height) { //setter opp en tekstboks over riktig NPC
 textBox(text, "black", "25px Arial", type[which].x + 20,type[which].y, "white", type[which].x +20,type[which].y -20, width,height);
}



class Npc{ //Generell NPC klasse
  constructor(sprite, x,y, width,height, spawnTile,viewTile) { //Generell NPC informasjo
    this.sprite = sprite;
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;

    this.frameX = 0;
    this.frameY = 0;

    this.npcSprite = new Image();
    this.npcSprite.src = this.sprite;
  }

  draw() { //Generell tegne funksjon
    drawSprite(this.npcSprite, this.width * this.frameX,this.height * this.frameY, this.width,this.height, this.x,this.y, this.width,this.height);
  }

  handleNPCframe() { //håndterer NPC frame
      if (this.frameX < 3 && this.moving) {
        this.frameX++;
      } else {
        this.frameX = 0;
      }
  }
}



class Guard extends Npc{ //Setter opp vakt klasse
  constructor(sprite, x,y, width,height, spawnTile, viewTile, distanceToEvent){ //vakt informasjon
    super(sprite, x,y, width,height);
    this.distanceToEvent = distanceToEvent;
    this.spawnTile = spawnTile;
    this.viewTile = viewTile;
  }

  spawn() { //"Spawner" en vakt ved riktig sted når siden laster eller nytt "map" laster
    for(let eachRow=0; eachRow<WORLD_ROW; eachRow++) {
      for(let eachCol=0; eachCol<WORLD_COL; eachCol++) {
        let arrayIndex = rowColToArrayIndex(eachCol, eachRow);
        if (worldGrid[arrayIndex] == this.spawnTile) {
          this.x = eachCol * TILE_W;
          this.y = eachRow * TILE_H - TILE_H/2;
          console.log(this.x, this.y);
          return;
        }
      }
    }
    console.log("NO NPC FOUND");
  }
}



class Enemy extends Npc { //Setter opp fiende klasse
  constructor(sprite, x,y, width,height, spawnTile,viewTile) { //Fiende informasjon
    super(sprite, x,y, width,height);
    this.spawnTile = spawnTile;
    this.viewTile = viewTile;
    this.speed = 5;
    this.moving = false;
  }

  spawn() {   //"Spawner" en fiende ved riktig sted når siden laster eller nytt "map" laster
    for(let eachRow=0; eachRow<WORLD_ROW; eachRow++) {
      for(let eachCol=0; eachCol<WORLD_COL; eachCol++) {
        let arrayIndex = rowColToArrayIndex(eachCol, eachRow);
        if (worldGrid[arrayIndex] == this.spawnTile) {
          this.x = eachCol * TILE_W;
          this.y = eachRow * TILE_H - TILE_H/2;
          return;
        }
      }
    }
    console.log("NO NPC FOUND");
  }
}



 class SalesMan extends Npc { //Setter opp handelsmann klasse
   constructor(sprite, x,y, width,height, spawnTile,viewTile){ //handelsmann informasjon
     super(sprite, x,y, width,height);
     this.spawnTile = spawnTile;
     this.viewTile = viewTile;
   }

   spawn() {  //"Spawner" en handelsmann ved riktig sted når siden laster eller nytt "map" laster
     for(let eachRow=0; eachRow<WORLD_ROW; eachRow++) {
       for(let eachCol=0; eachCol<WORLD_COL; eachCol++) {
         let arrayIndex = rowColToArrayIndex(eachCol, eachRow);
         if (worldGrid[arrayIndex] == this.spawnTile) {
           this.x = eachCol * TILE_W;
           this.y = eachRow * TILE_H - TILE_H/2;
           return;
         }
       }
     }
     console.log("NO SALESMAN FOUND");
   }
 }

 function setUpNPCs() { //Sørger for å opprette riktig antall NPC og riktig type når side laster eller nytt "map" laster
   guards = new Array; //sletter alle eksisterende NPCs før siden laster
   salesmen = new Array;
   enemies = new Array;
   for (let i = 0; i < worldGrid.length; i++) {

     if (worldGrid[i] == GUARD_SPAWN_BRICKS) {
       guards.push(new Guard("assets/chinese.png", 0,0, 32,48, GUARD_SPAWN_BRICKS,floorKind[currentLevel], 1));
     }
      if (worldGrid[i] == GUARD_SPAWN_PLANKS) {
       guards.push(new Guard("assets/chinese.png", 0,0, 32,48, GUARD_SPAWN_PLANKS,floorKind[currentLevel], 1));
     }

     if (worldGrid[i] == SALESMAN_SPAWN_BRICKS) {
       salesmen.push(new SalesMan("assets/salesman.png", 0,0, 32,48, SALESMAN_SPAWN_BRICKS,floorKind[currentLevel]));
     }
      if (worldGrid[i] == SALESMAN_SPAWN_PLANKS) {
       salesmen.push(new SalesMan("assets/salesman.png", 0,0, 32,48, SALESMAN_SPAWN_PLANKS,floorKind[currentLevel]));
     }
     if (worldGrid[i] == ENEMY_SPAWN_BRICKS) {
       enemies.push(new Enemy("assets/enemy_1.png", 0,0, 40,56, ENEMY_SPAWN_BRICKS,floorKind[currentLevel]));
     }
      if (worldGrid[i] == ENEMY_SPAWN_PLANKS) {
       enemies.push(new Enemy("assets/enemy_1.png", 0,0, 40,56, ENEMY_SPAWN_PLANKS,floorKind[currentLevel]));
     }
   }
 }
