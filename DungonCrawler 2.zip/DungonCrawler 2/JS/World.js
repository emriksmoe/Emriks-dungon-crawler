 //Håndterer alt av verdens tegninger

function returnTileTypeAtColRow(col, row) { //Finner hvilken tile som er hvor
  if (col >= 0 && col < WORLD_COL && row >= 0 && row < WORLD_ROW) {
    let tileIndexUnderPlayer = rowColToArrayIndex(col, row);
    return worldGrid[tileIndexUnderPlayer];
  }
}

function rowColToArrayIndex(col, row) { // index til hver tile brikke
  return col + WORLD_COL * row;
}

function isTileAtTileCoord(tileCol, tileRow) {
  let tileIndex = rowColToArrayIndex(tileCol, tileRow);
  return (worldGrid[tileIndex] == 1);
}

function tileTypeHasTransparency(checkTileType) { //Sjekker hvilke "tiles" som er gjennomsiktig, type våpen og items
  return (checkTileType == BATTERY_FRESH || checkTileType == TUBORG || checkTileType == WEPON_TILE_ONE
  || checkTileType == WEPON_TILE_TWO || checkTileType == WEPON_TILE_TREE || checkTileType == WEPON_TILE_FOUR
  || checkTileType == WEPON_TILE_FIVE || checkTileType == BRICK_BARS || checkTileType == LOG);
}



function drawWorld() { //tegner verden
  let arrayIndex = 0;
  let drawTileX = 0;
  let drawTileY = 0;

  for(let eachRow = 0; eachRow < WORLD_ROW; eachRow++){
    for(let eachCol = 0; eachCol < WORLD_COL; eachCol++){

      let arrayIndex = rowColToArrayIndex(eachCol, eachRow); // finner hvilken track som er hvilken
      let tileKindeHere = worldGrid[arrayIndex];
      let useImg = tilePics[tileKindeHere]; // henter hvilken tile

      if ( tileTypeHasTransparency(tileKindeHere) ) {
        let floorTile = floorKind[currentLevel];
        ctx.drawImage(tilePics[floorTile], drawTileX,drawTileY);
      }
      ctx.drawImage(useImg, drawTileX,drawTileY); //tegner tile

      drawTileX += TILE_W;
      arrayIndex++;
      // slutten av tegne track nr 1
    } // slutten hver kolonne
    drawTileX = 0;
    drawTileY += TILE_H;
  } // slutten av hver rad
} //slutten ad drawWorld

function getTileIndexAtPixelCoord(atX, atY) { //få til å funke på alle sider
  let playerWorldCol = Math.floor((atX + (player.width/2)) / TILE_W); //finner hvilken tile på raden
  let playerWorldRow = Math.floor((atY + player.height - 5) / TILE_H); //finner hvilken tile på kolonnen
  let tileIndexUnderPlayer = rowColToArrayIndex(playerWorldCol, playerWorldRow); //hvilklen tile er her

  if (playerWorldCol  >= 0 && playerWorldCol  < WORLD_COL &&
      playerWorldRow >= 0 && playerWorldRow< WORLD_ROW) {
    return tileIndexUnderPlayer;
    console.log(tileIndexUnderPlayer);
  }
  return undefined;
}
