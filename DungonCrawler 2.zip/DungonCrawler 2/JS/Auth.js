const auth = firebase.auth();
let user = firebase.auth().currentUser;

const btnLogIn = document.getElementById('btnLogIn');
const btnSignUp = document.getElementById('btnSignUp');
const btnCreateUser = document.getElementById('btnCreateUser');
const btnLogOut = document.getElementById('btnLogOut');
const btnBack = document.getElementById('btnBack');
const btnContinue= document.getElementById('continue');

const txtEmail = document.getElementById('txtEmail');
const txtPassword = document.getElementById('txtPassword');

const signupForm = document.getElementById('signupForm');

const skinOne = document.getElementById('skinOne');
const skinTwo = document.getElementById('skinTwo');



  auth.onAuthStateChanged(user => { //sjekker om bruker er logget inn
    if (user) {
      ref.on('value', gotData, errData);
      console.log("bruker logget inn som: ", user);
      showDisplay("playGame");
    } else {
      console.log("bruker logget ut");
      canvas.style.visibility = "hidden";
      showDisplay("start");
    }
  });



btnLogIn.addEventListener("click", e => { //logger inn eksisterende brukere
  const email = txtEmail.value;
  const pass = txtPassword.value;
  //sign in
  const promise = auth.signInWithEmailAndPassword(email, pass);
  promise.catch(e => console.log(e.message));
  txtEmail.value = "";
  txtPassword.value = "";
  showDisplay("playGame");
  btnContinue.style.visibility = "visible";
  beforeGameEl.style.visibility = "visible";
});


btnSignUp.addEventListener("click", e => { //tar deg videre til der du setter opp bruker
  showDisplay("createUser");
  txtEmail.value = "";
  txtPassword.value = "";
});


signupForm.addEventListener('submit', (e) => { //oppretter en bruker
  e.preventDefault();
  //henter informasjon
  const email = signupForm['signupEmail'].value;
  const pass = signupForm['signupPassword'].value;
  const userName = signupForm['signupUsername'].value;
  let whatSkin;

  if (skinOne.checked) {
    whatSkin = 0;
  }else if (skinTwo.checked) {
    whatSkin = 1;
  } else if (skinThree.checked) {
    whatSkin = 2;
  }
  //oppreter bruker
  auth.createUserWithEmailAndPassword(email, pass).then(function(result) {
    return result.user.updateProfile({
      displayName: userName,
    })
  }).then(function() {

  }).catch(function(error) {

  }).then(cred => {
    signupForm.reset();
    uploadNewPlayer(whatSkin);
  });
  btnContinue.style.visibility = "visible";
  beforeGameEl.style.visibility = "visible";
});


btnBack.addEventListener("click", e => { //Tar deg tilbake
  showDisplay("start");
  txtEmail.value = "";
  txtPassword.value = "";
});

//lager logg ut event


btnLogOut.addEventListener("click", e => { //logger deg ut
  auth.signOut();
  showDisplay("start");
  location.reload();
});

btnContinue.addEventListener("click", e => {
  btnContinue.style.visibility = "hidden";
  beforeGameEl.style.visibility = "hidden";
  location.reload();
});
